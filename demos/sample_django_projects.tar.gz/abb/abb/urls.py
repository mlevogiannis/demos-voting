from django.conf.urls import include, url
from django.contrib import admin

urlpatterns = [
    url(r'^', include('demos_abb.urls', namespace='demos_abb', app_name='demos_abb')),
    url(r'^admin/', include(admin.site.urls)),
]
