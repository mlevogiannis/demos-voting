from django.conf.urls import include, url
from django.contrib import admin

urlpatterns = [
    url(r'^', include('demos_bds.urls', namespace='demos_bds', app_name='demos_bds')),
    url(r'^admin/', include(admin.site.urls)),
]
