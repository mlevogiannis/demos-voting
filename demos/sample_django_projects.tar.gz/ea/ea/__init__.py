# File: __init__.py

from .celery import app as celery_app
