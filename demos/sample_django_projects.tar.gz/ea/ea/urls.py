from django.conf.urls import include, url
from django.contrib import admin

urlpatterns = [
    url(r'^', include('demos_ea.urls', namespace='demos_ea', app_name='demos_ea')),
    url(r'^admin/', include(admin.site.urls)),
]
