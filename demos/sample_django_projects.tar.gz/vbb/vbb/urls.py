from django.conf.urls import include, url
from django.contrib import admin

urlpatterns = [
    url(r'^', include('demos_vbb.urls', namespace='demos_vbb', app_name='demos_vbb')),
    url(r'^admin/', include(admin.site.urls)),
]
